package org.xtext.example.mydsl4;

import com.google.common.base.Objects;
import com.google.common.collect.Iterators;
import java.util.Iterator;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.resource.DerivedStateAwareResource;
import org.eclipse.xtext.resource.IDerivedStateComputer;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.xtext.example.mydsl4.myDsl.Joint;
import org.xtext.example.mydsl4.myDsl.JointRef;
import org.xtext.example.mydsl4.myDsl.JointType;
import org.xtext.example.mydsl4.myDsl.Link;
import org.xtext.example.mydsl4.myDsl.MyDslFactory;
import org.xtext.example.mydsl4.myDsl.Robot;
import org.xtext.example.mydsl4.myDsl.Topology;

@SuppressWarnings("all")
public class MyDsl4DerivedStateComputer implements IDerivedStateComputer {
  @Override
  public void discardDerivedState(final DerivedStateAwareResource resource) {
    TreeIterator<EObject> _allContents = resource.getAllContents();
    Iterator<Topology> _filter = Iterators.<Topology>filter(_allContents, Topology.class);
    final Procedure1<Topology> _function = (Topology topo) -> {
      topo.setParent(null);
      topo.setChild(null);
      JointRef _joint = topo.getJoint();
      /* Objects.equal(_joint, null); */
    };
    IteratorExtensions.<Topology>forEach(_filter, _function);
  }
  
  @Override
  public void installDerivedState(final DerivedStateAwareResource resource, final boolean preLinkingPhase) {
    if ((!preLinkingPhase)) {
      TreeIterator<EObject> _allContents = resource.getAllContents();
      Iterator<Robot> _filter = Iterators.<Robot>filter(_allContents, Robot.class);
      final Procedure1<Robot> _function = (Robot robo) -> {
        TreeIterator<EObject> _eAllContents = robo.eAllContents();
        Iterator<Topology> _filter_1 = Iterators.<Topology>filter(_eAllContents, Topology.class);
        final Procedure1<Topology> _function_1 = (Topology topo) -> {
          if (((!Objects.equal(topo.getParent(), null)) && 
            (!IteratorExtensions.<Link>exists(Iterators.<Link>filter(robo.eAllContents(), Link.class), ((Function1<Link, Boolean>) (Link x) -> {
              String _name = x.getName();
              String _parent = topo.getParent();
              String _string = _parent.toString();
              return Boolean.valueOf(_name.equals(_string));
            }))))) {
            EList<Link> _link = robo.getLink();
            Link _createLink = MyDslFactory.eINSTANCE.createLink();
            final Procedure1<Link> _function_2 = (Link it) -> {
              String _parent = topo.getParent();
              String _string = _parent.toString();
              it.setName(_string);
            };
            Link _doubleArrow = ObjectExtensions.<Link>operator_doubleArrow(_createLink, _function_2);
            _link.add(_doubleArrow);
          }
          if (((!Objects.equal(topo.getChild(), null)) && 
            (!IteratorExtensions.<Link>exists(Iterators.<Link>filter(robo.eAllContents(), Link.class), 
              ((Function1<Link, Boolean>) (Link x) -> {
                String _name = x.getName();
                Topology _child = topo.getChild();
                String _parent = _child.getParent();
                String _string = _parent.toString();
                return Boolean.valueOf(_name.equals(_string));
              }))))) {
            EList<Link> _link_1 = robo.getLink();
            Link _createLink_1 = MyDslFactory.eINSTANCE.createLink();
            final Procedure1<Link> _function_3 = (Link it) -> {
              Topology _child = topo.getChild();
              String _parent = _child.getParent();
              String _string = _parent.toString();
              it.setName(_string);
            };
            Link _doubleArrow_1 = ObjectExtensions.<Link>operator_doubleArrow(_createLink_1, _function_3);
            _link_1.add(_doubleArrow_1);
          }
          JointRef _joint = topo.getJoint();
          boolean _notEquals = (!Objects.equal(_joint, null));
          if (_notEquals) {
            EList<Joint> _joint_1 = robo.getJoint();
            Joint _createJoint = MyDslFactory.eINSTANCE.createJoint();
            final Procedure1<Joint> _function_4 = (Joint it) -> {
              String _parent = topo.getParent();
              String _string = _parent.toString();
              String _plus = (_string + "_");
              Topology _child = topo.getChild();
              String _parent_1 = _child.getParent();
              String _string_1 = _parent_1.toString();
              String _plus_1 = (_plus + _string_1);
              it.setName(_plus_1);
              JointRef _joint_2 = topo.getJoint();
              String _fix = _joint_2.getFix();
              boolean _notEquals_1 = (!Objects.equal(_fix, null));
              if (_notEquals_1) {
                it.setType(JointType.FIXED);
              } else {
                JointRef _joint_3 = topo.getJoint();
                String _rev = _joint_3.getRev();
                boolean _notEquals_2 = (!Objects.equal(_rev, null));
                if (_notEquals_2) {
                  it.setType(JointType.REVOLUTE);
                } else {
                  JointRef _joint_4 = topo.getJoint();
                  String _pris = _joint_4.getPris();
                  boolean _notEquals_3 = (!Objects.equal(_pris, null));
                  if (_notEquals_3) {
                    it.setType(JointType.PRISMATIC);
                  } else {
                    it.setType(JointType.CONTINUOUS);
                  }
                }
              }
            };
            Joint _doubleArrow_2 = ObjectExtensions.<Joint>operator_doubleArrow(_createJoint, _function_4);
            _joint_1.add(_doubleArrow_2);
          }
        };
        IteratorExtensions.<Topology>forEach(_filter_1, _function_1);
      };
      IteratorExtensions.<Robot>forEach(_filter, _function);
    }
  }
}
